using System;
using System.Collections.Generic;
using UnityEngine;

namespace IsleOfVerdure.AnimalCodex
{
    public sealed class AnimalCodexProgress : MonoBehaviour
    {
        [Serializable] public sealed class Record { public string id; public AnimalDiscovery state; }
        [Serializable] public sealed class SaveDocument { public int version = 1; public List<Record> records = new List<Record>(); }
        [SerializeField] private string saveKey = "IsleOfVerdure.AnimalCodex.v1";
        private readonly Dictionary<string, AnimalDiscovery> states = new Dictionary<string, AnimalDiscovery>();
        public event Action<string> Changed;
        public AnimalDiscovery GetState(string id) { AnimalDiscovery result; return states.TryGetValue(id, out result) ? result : AnimalDiscovery.Undiscovered; }
        private void Awake() { Load(); }

        public bool MarkDiscovered(AnimalCatalog catalog, string id) { return Promote(catalog, id, AnimalDiscovery.Discovered); }
        public bool MarkCollected(AnimalCatalog catalog, string id) { return Promote(catalog, id, AnimalDiscovery.Collected); }
        private bool Promote(AnimalCatalog catalog, string id, AnimalDiscovery state)
        {
            if (catalog == null || catalog.Find(id) == null || GetState(id) >= state) return false;
            states[id] = state; Save();
            if (Changed != null) Changed(id);
            return true;
        }

        public string ExportJson()
        {
            var data = new SaveDocument();
            foreach (var pair in states) data.records.Add(new Record { id = pair.Key, state = pair.Value });
            data.records.Sort((a,b) => string.CompareOrdinal(a.id,b.id));
            return JsonUtility.ToJson(data, true);
        }
        public void ImportJson(string json)
        {
            if (string.IsNullOrEmpty(json)) return;
            var data = JsonUtility.FromJson<SaveDocument>(json);
            if (data == null || data.version != 1 || data.records == null) throw new FormatException("Unsupported animal save.");
            var next = new Dictionary<string, AnimalDiscovery>();
            foreach (var entry in data.records)
            {
                if (entry == null || string.IsNullOrEmpty(entry.id) || !Enum.IsDefined(typeof(AnimalDiscovery), entry.state)) continue;
                AnimalDiscovery old;
                if (!next.TryGetValue(entry.id, out old) || entry.state > old) next[entry.id] = entry.state;
            }
            states.Clear(); foreach (var pair in next) states.Add(pair.Key,pair.Value);
            if (Changed != null) Changed(null);
        }
        public void Save() { PlayerPrefs.SetString(saveKey, ExportJson()); PlayerPrefs.Save(); }
        public void Load()
        {
            try { ImportJson(PlayerPrefs.GetString(saveKey, "")); }
            catch (Exception error) { Debug.LogWarning("Animal codex save could not be read; original save retained. " + error.Message, this); }
        }
    }
}
