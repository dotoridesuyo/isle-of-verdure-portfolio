using System;
using System.Collections.Generic;
using UnityEngine;

namespace IsleOfVerdure.AnimalCodex
{
    public enum AnimalRarity { Common, Uncommon, Rare, Legendary }
    public enum AnimalSkill { Water, Growth, Weed, Harvest, Quality, Yield, Gold }
    public enum AnimalAbilityMode { Action, Passive, HarvestModifier }
    public enum AnimalFacing { Up, Right, Down, Left }
    public enum AnimalDiscovery { Undiscovered, Discovered, Collected }

    [Serializable]
    public sealed class AnimalGrade
    {
        public AnimalRarity rarity;
        public string label;
        public int width;
        public int depth;
        public string colorHex;
        public int CellCount { get { return width * depth; } }
    }

    [Serializable]
    public sealed class AnimalDefinition
    {
        public string id;
        public string displayName;
        public string title;
        public string species;
        public AnimalRarity rarity;
        public AnimalSkill skill;
        public AnimalAbilityMode mode;
        public string role;
        [TextArea] public string concept;
        [TextArea] public string personality;
        [TextArea] public string appearance;
        [TextArea] public string primaryAbility;
        [TextArea] public string animation;
        [TextArea] public string meeting;
        [TextArea] public string quote;
        public int portraitIndex;
    }

    [Serializable]
    public sealed class AnimalCatalogDocument
    {
        public string schemaVersion;
        public string balanceStatus;
        public AnimalGrade[] grades;
        public AnimalDefinition[] animals;
    }

    [CreateAssetMenu(menuName = "Isle of Verdure/Animal Catalog", fileName = "AnimalCatalog")]
    public sealed class AnimalCatalog : ScriptableObject
    {
        public const string ResourcePath = "VerdureAnimalCodex/animal-catalog";
        [SerializeField] private AnimalCatalogDocument document = new AnimalCatalogDocument();
        public AnimalDefinition[] Animals { get { return document.animals ?? new AnimalDefinition[0]; } }
        public AnimalGrade[] Grades { get { return document.grades ?? new AnimalGrade[0]; } }

        public AnimalDefinition Find(string id)
        {
            foreach (var animal in Animals) if (animal.id == id) return animal;
            return null;
        }

        public AnimalGrade Grade(AnimalRarity rarity)
        {
            foreach (var grade in Grades) if (grade.rarity == rarity) return grade;
            throw new InvalidOperationException("Missing animal grade: " + rarity);
        }

        public void LoadJson(string json)
        {
            var parsed = JsonUtility.FromJson<AnimalCatalogDocument>(json);
            Validate(parsed);
            document = parsed;
        }

        public void Validate() { Validate(document); }

        private static void Validate(AnimalCatalogDocument value)
        {
            if (value == null || value.schemaVersion != "1.0" || value.grades == null || value.grades.Length != 4 || value.animals == null)
                throw new InvalidOperationException("Animal catalog schema 1.0 with four grades is required.");
            var gradeIds = new HashSet<AnimalRarity>();
            foreach (var grade in value.grades)
            {
                if (!Enum.IsDefined(typeof(AnimalRarity), grade.rarity) || !gradeIds.Add(grade.rarity) || grade.width < 1 || grade.width > 3 || grade.depth < 1 || grade.depth > 3)
                    throw new InvalidOperationException("Invalid or duplicate animal grade.");
            }
            var ids = new HashSet<string>();
            foreach (var animal in value.animals)
            {
                if (animal == null || string.IsNullOrEmpty(animal.id) || !ids.Add(animal.id) || string.IsNullOrEmpty(animal.displayName)
                    || !gradeIds.Contains(animal.rarity) || !Enum.IsDefined(typeof(AnimalSkill), animal.skill)
                    || !Enum.IsDefined(typeof(AnimalAbilityMode), animal.mode) || animal.portraitIndex < 0 || animal.portraitIndex > 9)
                    throw new InvalidOperationException("Invalid or duplicate animal entry.");
            }
        }

        public static AnimalCatalog LoadDefault()
        {
            var text = Resources.Load<TextAsset>(ResourcePath);
            if (text == null) throw new InvalidOperationException("Missing Resources/" + ResourcePath + ".json");
            var catalog = CreateInstance<AnimalCatalog>();
            catalog.name = "AnimalCatalog (Runtime)";
            catalog.LoadJson(text.text);
            return catalog;
        }
    }
}
