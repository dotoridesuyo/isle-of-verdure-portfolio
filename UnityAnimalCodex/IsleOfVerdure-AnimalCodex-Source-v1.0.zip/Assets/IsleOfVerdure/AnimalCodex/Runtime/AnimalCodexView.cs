using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace IsleOfVerdure.AnimalCodex
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster))]
    public sealed class AnimalCodexView : MonoBehaviour
    {
        [SerializeField] private AnimalCatalog catalog;
        [SerializeField] private Font koreanFont;
        [Tooltip("Full reference preview. Does not mark the real collection as collected.")]
        [SerializeField] private bool previewAllEntries = true;
        [SerializeField] private AnimalCodexProgress progress;
        private Font font;
        private bool ownsFont, ownsCatalog;
        private Texture2D atlas;
        private RectTransform root, book, leftPage, rightPage, grid, viewport, detail;
        private GridLayoutGroup gridLayout;
        private InputField search;
        private Text count, skillLabel, modeLabel, stateLabel;
        private readonly List<Button> rarityButtons = new List<Button>();
        private string selectedId = "A001", query = "";
        private int rarityChoice = -1, skillChoice = -1, modeChoice = -1, stateChoice;
        private bool animationTab;
        private AnimalFacing facing = AnimalFacing.Down;
        private Vector2 lastSize;
        public event Action<AnimalDefinition> Selected;
        public event Action CloseRequested;
        private static readonly Color Paper = new Color32(255,250,235,255);
        private static readonly Color Sage = new Color32(109,128,91,255);
        private static readonly Color Ink = new Color32(91,88,65,255);
        private static readonly Color Muted = new Color32(133,137,112,255);

        public void Configure(AnimalCatalog source, Font assignedFont = null)
        { catalog = source; koreanFont = assignedFont; }

        public void Open(string animalId = null)
        {
            if (!string.IsNullOrEmpty(animalId)) selectedId = animalId;
            gameObject.SetActive(true);
            if (root != null) { ResetFilters(); RefreshGrid(); }
        }

        private void OnEnable()
        {
            if (!Application.isPlaying) return;
            try { BuildView(); }
            catch (Exception error) { Debug.LogError("Animal codex initialization failed: " + error, this); }
        }

        private void OnDisable()
        {
            if (progress != null) progress.Changed -= OnProgressChanged;
        }

        private void OnDestroy()
        {
            if (ownsCatalog && catalog != null) Destroy(catalog);
            if (ownsFont && font != null) Destroy(font);
        }

        private void BuildView()
        {
            if (root != null) { root.gameObject.SetActive(false); Destroy(root.gameObject); }
            if (catalog == null) { catalog = AnimalCatalog.LoadDefault(); ownsCatalog = true; }
            catalog.Validate();
            if (progress == null) progress = GetComponent<AnimalCodexProgress>() ?? gameObject.AddComponent<AnimalCodexProgress>();
            progress.Changed -= OnProgressChanged;
            progress.Changed += OnProgressChanged;
            if (font == null)
            {
                font = koreanFont;
                if (font == null)
                {
                    font = Font.CreateDynamicFontFromOSFont(new[] { "Malgun Gothic", "Apple SD Gothic Neo", "Noto Sans CJK KR", "Arial" }, 18);
                    ownsFont = font != null;
                }
                if (font == null)
                {
#if UNITY_2022_2_OR_NEWER
                    font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                    font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                }
            }
            atlas = Resources.Load<Texture2D>("VerdureAnimalCodex/animal-portraits");
            if (atlas == null) Debug.LogWarning("Animal portrait atlas is missing.", this);
            EnsureEventSystem();
            root = Panel(transform, "Animal Codex UI", new Color32(233,237,222,255)); Stretch(root,0,0,0,0);
            var heading = Label(root,"신록의 섬  /  동물 친구 도감",28,Ink); Box(heading.rectTransform,24,-22,760,45);
            var close = Button(root,"닫기",() => { if (CloseRequested != null) CloseRequested(); else gameObject.SetActive(false); });
            Box(close.GetComponent<RectTransform>(),-95,-24,72,38);
            close.GetComponent<RectTransform>().anchorMin = close.GetComponent<RectTransform>().anchorMax = new Vector2(1,1);
            book = Panel(root,"Specimen Book",Sage); Stretch(book,20,86,20,20);
            leftPage = Panel(book,"Companion List",new Color32(250,247,234,255));
            rightPage = Panel(book,"Companion Detail",Paper);
            LabelAt(leftPage,"THE COMPANION JOURNAL",12,Muted,18,-14,320,22);
            LabelAt(leftPage,"정원에서 만난 친구들",23,Ink,18,-38,350,36);
            search = SearchField(leftPage); Box(search.GetComponent<RectTransform>(),18,-82,340,34);
            search.onValueChanged.AddListener(value => { query = value.Trim(); RefreshGrid(); });
            var gradeRow = Horizontal(leftPage,"등급 필터",6); Box(gradeRow,18,-124,340,32);
            rarityButtons.Clear();
            for (int i=-1;i<4;i++)
            {
                int choice=i;
                var button=Button(gradeRow,i<0?"전체":catalog.Grade((AnimalRarity)i).label,()=> {rarityChoice=choice;RefreshGrid();});
                rarityButtons.Add(button);
            }
            var filters = Horizontal(leftPage,"능력·수집 필터",5); Box(filters,18,-166,340,32);
            skillLabel = Button(filters,"능력: 전체",()=>{skillChoice++;if(skillChoice>6)skillChoice=-1;RefreshGrid();}).GetComponentInChildren<Text>();
            modeLabel = Button(filters,"유형: 전체",()=>{modeChoice++;if(modeChoice>2)modeChoice=-1;RefreshGrid();}).GetComponentInChildren<Text>();
            stateLabel = Button(filters,"수집: 전체",()=>{stateChoice=(stateChoice+1)%3;RefreshGrid();}).GetComponentInChildren<Text>();
            var reset=Button(leftPage,"검색·필터 초기화",ResetFilters); Box(reset.GetComponent<RectTransform>(),18,-207,165,28);
            count=LabelAt(leftPage,"",12,Muted,18,-239,350,24);
            ScrollRect listScroll; grid=Scroll(leftPage,"카드 목록",out listScroll); Stretch(listScroll.GetComponent<RectTransform>(),16,274,16,16);
            viewport=listScroll.viewport;
            gridLayout=grid.gameObject.AddComponent<GridLayoutGroup>();
            gridLayout.constraint=GridLayoutGroup.Constraint.FixedColumnCount;gridLayout.constraintCount=3;
            gridLayout.spacing=new Vector2(8,8);gridLayout.padding=new RectOffset(2,2,2,2);
            grid.gameObject.AddComponent<ContentSizeFitter>().verticalFit=ContentSizeFitter.FitMode.PreferredSize;
            ScrollRect detailScroll; detail=Scroll(rightPage,"詳細",out detailScroll);Stretch(detailScroll.GetComponent<RectTransform>(),18,18,18,18);
            Vertical(detail,12);detail.gameObject.AddComponent<ContentSizeFitter>().verticalFit=ContentSizeFitter.FitMode.PreferredSize;
            LayoutPanels(true); RefreshGrid();
        }

        private void Update() { if(root!=null)LayoutPanels(false); }
        private void LayoutPanels(bool force)
        {
            var size=root.rect.size;if(!force&&size==lastSize)return;lastSize=size;
            bool narrow=size.x<900;
            SetAnchors(leftPage,narrow?new Vector2(0,.51f):Vector2.zero,narrow?Vector2.one:new Vector2(.48f,1),8);
            SetAnchors(rightPage,narrow?Vector2.zero:new Vector2(.48f,0),narrow?new Vector2(1,.51f):Vector2.one,8);
            Canvas.ForceUpdateCanvases();
            var heading=root.Find("Text") as RectTransform;
            if(heading!=null)heading.sizeDelta=new Vector2(Mathf.Max(180,size.x-140),45);
            foreach (var name in new[]{"Search", "등급 필터", "능력·수집 필터"})
            {
                var child=leftPage.Find(name) as RectTransform;if(child!=null)child.sizeDelta=new Vector2(Mathf.Max(200,leftPage.rect.width-36),child.sizeDelta.y);
            }
            if(search!=null)search.GetComponent<RectTransform>().sizeDelta=new Vector2(Mathf.Max(200,leftPage.rect.width-36),34);
            if(gridLayout!=null)gridLayout.cellSize=new Vector2(Mathf.Max(64,(viewport.rect.width-20)/3),152);
        }

        private AnimalDiscovery Discovery(AnimalDefinition animal)
        { return previewAllEntries?AnimalDiscovery.Collected:progress.GetState(animal.id); }
        private void OnProgressChanged(string id) { if(root!=null)RefreshGrid(); }
        private void ResetFilters()
        {
            rarityChoice=skillChoice=modeChoice=-1;stateChoice=0;query="";
            if(search!=null)search.SetTextWithoutNotify("");RefreshGrid();
        }

        private void RefreshGrid()
        {
            if(grid==null)return;
            Clear(grid);
            var visible=catalog.Animals.Where(a=>
                (rarityChoice<0 || (Discovery(a)!=AnimalDiscovery.Undiscovered && (int)a.rarity==rarityChoice)) &&
                (skillChoice<0 || (Discovery(a)!=AnimalDiscovery.Undiscovered && (int)a.skill==skillChoice)) &&
                (modeChoice<0 || (Discovery(a)!=AnimalDiscovery.Undiscovered && (int)a.mode==modeChoice)) &&
                (stateChoice==0 || (stateChoice==1?Discovery(a)==AnimalDiscovery.Collected:Discovery(a)==AnimalDiscovery.Undiscovered)) &&
                (string.IsNullOrEmpty(query) || (Discovery(a)!=AnimalDiscovery.Undiscovered &&
                  (a.id+" "+a.displayName+" "+a.species+" "+a.role+" "+catalog.Grade(a.rarity).label).IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0))).ToList();
            if(visible.Count>0&&!visible.Any(a=>a.id==selectedId))selectedId=visible[0].id;
            foreach(var animal in visible)
            {
                var a=animal;bool locked=Discovery(a)==AnimalDiscovery.Undiscovered;
                var button=Button(grid,"",()=>{selectedId=a.id;animationTab=false;RefreshGrid();if(Selected!=null)Selected(a);});
                var layout=button.gameObject.AddComponent<VerticalLayoutGroup>();layout.padding=new RectOffset(4,4,6,5);layout.spacing=2;layout.childAlignment=TextAnchor.MiddleCenter;layout.childControlHeight=true;layout.childControlWidth=true;layout.childForceExpandHeight=false;
                Clear(button.transform);
                var badge=Label(button.transform,locked?"???":catalog.Grade(a.rarity).label,11,locked?Muted:GradeColor(a.rarity));Height(badge.gameObject,18);badge.alignment=TextAnchor.MiddleRight;
                Portrait(button.transform,a,78,locked);
                var title=Label(button.transform,locked?"미발견":a.displayName,16,Ink);title.alignment=TextAnchor.MiddleCenter;Height(title.gameObject,24);
                var sub=Label(button.transform,locked?"만남의 기록":a.species+" · "+catalog.Grade(a.rarity).CellCount+"칸",11,Muted);sub.alignment=TextAnchor.MiddleCenter;Height(sub.gameObject,18);
                button.image.color=a.id==selectedId?new Color32(227,235,207,255):new Color32(255,252,242,255);
            }
            if(visible.Count==0){var empty=Label(grid,"조건에 맞는 친구가 없어요.\n검색·필터를 초기화해 주세요.",14,Muted);empty.alignment=TextAnchor.MiddleCenter;}
            int collected=catalog.Animals.Count(a=>Discovery(a)==AnimalDiscovery.Collected);
            count.text=string.Format("수집 {0}/{1}종 · 현재 {2}종 표시",collected,catalog.Animals.Length,visible.Count);
            for(int i=0;i<rarityButtons.Count;i++)rarityButtons[i].image.color=rarityChoice==i-1?new Color32(218,230,199,255):new Color32(243,242,228,255);
            skillLabel.text=skillChoice<0?"능력: 전체":SkillLabel((AnimalSkill)skillChoice);
            modeLabel.text=modeChoice<0?"유형: 전체":ModeLabel((AnimalAbilityMode)modeChoice);
            stateLabel.text=new[]{"수집: 전체","수집 완료","미발견"}[stateChoice];
            RenderDetail();
        }

        private void RenderDetail()
        {
            Clear(detail);var a=catalog.Find(selectedId);if(a==null)return;
            bool locked=Discovery(a)==AnimalDiscovery.Undiscovered;
            Label(detail,"COMPANION JOURNAL / "+a.id,12,Muted);
            var hero=Horizontal(detail,"친구 소개",18);Height(hero.gameObject,195);
            var titleColumn=Vertical(Panel(hero,"이름",Color.clear),9);Flex(titleColumn.gameObject);
            Label(titleColumn,locked?"미발견 친구":a.displayName,32,Ink);
            if(!locked){Label(titleColumn,a.title,16,Muted);Label(titleColumn,catalog.Grade(a.rarity).label+" · "+a.species,14,GradeColor(a.rarity));}
            Portrait(hero,a,175,locked);
            if(locked){Label(detail,"만남 힌트",17,Sage);Label(detail,a.meeting,16,Muted);return;}
            Label(detail,a.concept,16,Muted);
            var grade=catalog.Grade(a.rarity);
            Info(detail,"정원 역할",a.role);Info(detail,"관리 범위",string.Format("전방 {0}칸 · 너비 {1} × 깊이 {2}",grade.CellCount,grade.width,grade.depth));
            var tabs=Horizontal(detail,"상세 탭",8);
            Button(tabs,"컨셉 · 배치",()=>{animationTab=false;RenderDetail();});Button(tabs,"연출",()=>{animationTab=true;RenderDetail();});
            if(animationTab)Info(detail,"대기·작동",a.animation);
            else
            {
                Info(detail,"캐릭터 컨셉",a.personality);Info(detail,"외형 컨셉",a.appearance);Info(detail,"등장 컨셉",a.meeting);
                Label(detail,"능력 · 배치",20,Sage);
                var directions=Horizontal(detail,"바라보는 방향",6);
                for(int i=0;i<4;i++){var value=(AnimalFacing)i;Button(directions,new[]{"위","오른쪽","아래","왼쪽"}[i],()=>{facing=value;RenderDetail();});}
                RenderRange(detail,grade);
                Info(detail,"배치 기준","모서리 배치 · 방향별 범위 전환 · 식재 칸 점유 없음");
                Info(detail,"주요 능력",a.primaryAbility);Info(detail,"적용 유형",ModeLabel(a.mode));
            }
            var quote=Panel(detail,"소개 대사",new Color32(245,238,216,255));Vertical(quote,6).GetComponent<VerticalLayoutGroup>().padding=new RectOffset(15,15,13,13);
            Label(quote,"소개 대사",13,Muted);Label(quote,a.quote,18,Ink);
        }

        private void RenderRange(Transform parent,AnimalGrade grade)
        {
            var container=Panel(parent,"관리 범위 도식",Color.clear);Height(container.gameObject,204);
            var board=Panel(container,"범위 격자",Color.clear);board.anchorMin=board.anchorMax=new Vector2(.5f,.5f);board.pivot=new Vector2(.5f,.5f);board.sizeDelta=new Vector2(192,192);
            var layout=board.gameObject.AddComponent<GridLayoutGroup>();layout.cellSize=new Vector2(29,29);layout.spacing=new Vector2(3,3);
            var cells=new HashSet<Vector2Int>(AnimalRangeUtility.GetCells(grade,Vector2Int.zero,facing));
            for(int row=0;row<6;row++)for(int col=0;col<6;col++)Panel(board,"칸",cells.Contains(new Vector2Int(col-3,2-row))?GradeColor(grade.rarity):(Color)new Color32(232,233,215,255));
            var marker=Label(container,new[]{"↑","→","↓","←"}[(int)facing],25,Ink);marker.alignment=TextAnchor.MiddleCenter;
            var rect=marker.rectTransform;rect.anchorMin=rect.anchorMax=new Vector2(.5f,.5f);rect.pivot=new Vector2(.5f,.5f);rect.sizeDelta=new Vector2(32,32);rect.anchoredPosition=new Vector2(-1.5f,1.5f);
        }

        private Color GradeColor(AnimalRarity rarity)
        { Color value;return ColorUtility.TryParseHtmlString(catalog.Grade(rarity).colorHex,out value)?value:Sage; }
        private static string SkillLabel(AnimalSkill skill)
        {return new[]{"자동 물주기","성장 속도 증가","잡초 자동 제거","자동 수확","품질 확률 증가","추가 수확량","황금 확률 증가"}[(int)skill];}
        private static string ModeLabel(AnimalAbilityMode mode)
        {return new[]{"행동형","상시 보정형","수확 판정 보정형"}[(int)mode];}
        private static void EnsureEventSystem()
        {
            if(FindObjectOfType<EventSystem>()!=null)return;
            var input=new GameObject("Animal Codex EventSystem",typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            input.AddComponent<InputSystemUIInputModule>().AssignDefaultActions();
#else
            input.AddComponent<StandaloneInputModule>();
#endif
        }
        private RawImage Portrait(Transform parent,AnimalDefinition animal,float size,bool silhouette)
        {
            var image=new GameObject("Portrait "+animal.id,typeof(RectTransform),typeof(RawImage)).GetComponent<RawImage>();image.transform.SetParent(parent,false);image.texture=atlas;
            image.uvRect=new Rect(animal.portraitIndex%5*.2f,animal.portraitIndex<5?.5f:0,.2f,.5f);
            image.color=silhouette?(Color)new Color32(80,86,66,255):Color.white;image.raycastTarget=false;
            var element=image.gameObject.AddComponent<LayoutElement>();element.preferredWidth=size;element.preferredHeight=size;element.minWidth=size;element.minHeight=size;
            return image;
        }
        private RectTransform Panel(Transform parent,string name,Color color)
        {var rect=new GameObject(name,typeof(RectTransform),typeof(Image)).GetComponent<RectTransform>();rect.SetParent(parent,false);rect.GetComponent<Image>().color=color;return rect;}
        private Text Label(Transform parent,string value,int size,Color color)
        {
            var text=new GameObject("Text",typeof(RectTransform),typeof(Text)).GetComponent<Text>();text.transform.SetParent(parent,false);text.font=font;text.fontSize=size;text.color=color;text.text=value;text.supportRichText=false;text.raycastTarget=false;text.horizontalOverflow=HorizontalWrapMode.Wrap;text.verticalOverflow=VerticalWrapMode.Overflow;return text;
        }
        private Text LabelAt(Transform parent,string value,int size,Color color,float x,float y,float width,float height)
        {var text=Label(parent,value,size,color);Box(text.rectTransform,x,y,width,height);return text;}
        private Button Button(Transform parent,string value,Action action)
        {
            var rect=Panel(parent,"Button "+value,new Color32(239,241,225,255));var button=rect.gameObject.AddComponent<Button>();button.targetGraphic=rect.GetComponent<Image>();button.onClick.AddListener(()=>action());
            var text=Label(rect,value,13,Ink);text.alignment=TextAnchor.MiddleCenter;Stretch(text.rectTransform,4,2,4,2);Height(rect.gameObject,34);Flex(rect.gameObject);return button;
        }
        private RectTransform Horizontal(Transform parent,string name,float spacing)
        {var rect=Panel(parent,name,Color.clear);var layout=rect.gameObject.AddComponent<HorizontalLayoutGroup>();layout.spacing=spacing;layout.childControlHeight=true;layout.childControlWidth=true;layout.childForceExpandHeight=false;layout.childForceExpandWidth=false;return rect;}
        private RectTransform Vertical(RectTransform rect,float spacing)
        {var layout=rect.gameObject.AddComponent<VerticalLayoutGroup>();layout.spacing=spacing;layout.childControlHeight=true;layout.childControlWidth=true;layout.childForceExpandHeight=false;layout.childForceExpandWidth=true;return rect;}
        private void Info(Transform parent,string label,string value)
        {var row=Horizontal(parent,label,12);var title=Label(row,label,14,Muted);var element=title.gameObject.AddComponent<LayoutElement>();element.preferredWidth=91;element.minWidth=91;var body=Label(row,value,16,Ink);Flex(body.gameObject);}
        private InputField SearchField(Transform parent)
        {
            var rect=Panel(parent,"Search",new Color32(237,239,224,255));var input=rect.gameObject.AddComponent<InputField>();input.targetGraphic=rect.GetComponent<Image>();input.lineType=InputField.LineType.SingleLine;
            var text=Label(rect,"",16,Ink);Stretch(text.rectTransform,9,4,9,4);input.textComponent=text;
            var placeholder=Label(rect,"친구 이름·종·등급 검색",14,Muted);Stretch(placeholder.rectTransform,9,4,9,4);input.placeholder=placeholder;return input;
        }
        private RectTransform Scroll(Transform parent,string name,out ScrollRect scroll)
        {
            var rect=Panel(parent,name,Color.clear);scroll=rect.gameObject.AddComponent<ScrollRect>();scroll.horizontal=false;scroll.movementType=ScrollRect.MovementType.Clamped;scroll.scrollSensitivity=28;
            var view=Panel(rect,"Viewport",Color.clear);Stretch(view,0,0,0,0);view.gameObject.AddComponent<RectMask2D>();
            var content=new GameObject("Content",typeof(RectTransform)).GetComponent<RectTransform>();content.SetParent(view,false);content.anchorMin=new Vector2(0,1);content.anchorMax=Vector2.one;content.pivot=new Vector2(.5f,1);content.anchoredPosition=Vector2.zero;content.sizeDelta=Vector2.zero;scroll.viewport=view;scroll.content=content;return content;
        }
        private static void Height(GameObject go,float value)
        {var element=go.GetComponent<LayoutElement>()??go.AddComponent<LayoutElement>();element.preferredHeight=value;element.minHeight=value;}
        private static void Flex(GameObject go)
        {var element=go.GetComponent<LayoutElement>()??go.AddComponent<LayoutElement>();element.flexibleWidth=1;}
        private static void Stretch(RectTransform rect,float left,float top,float right,float bottom)
        {rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=new Vector2(left,bottom);rect.offsetMax=new Vector2(-right,-top);}
        private static void Box(RectTransform rect,float x,float y,float width,float height)
        {rect.anchorMin=rect.anchorMax=new Vector2(0,1);rect.pivot=new Vector2(0,1);rect.anchoredPosition=new Vector2(x,y);rect.sizeDelta=new Vector2(width,height);}
        private static void SetAnchors(RectTransform rect,Vector2 min,Vector2 max,float padding)
        {rect.anchorMin=min;rect.anchorMax=max;rect.offsetMin=new Vector2(padding,padding);rect.offsetMax=new Vector2(-padding,-padding);}
        private static void Clear(Transform parent)
        {for(int i=parent.childCount-1;i>=0;i--){var child=parent.GetChild(i).gameObject;child.SetActive(false);if(Application.isPlaying)Destroy(child);else DestroyImmediate(child);}}
    }
}
