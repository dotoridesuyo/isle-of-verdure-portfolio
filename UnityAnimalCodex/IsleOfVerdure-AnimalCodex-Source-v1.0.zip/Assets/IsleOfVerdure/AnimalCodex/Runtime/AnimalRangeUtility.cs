using System;
using System.Collections.Generic;
using UnityEngine;

namespace IsleOfVerdure.AnimalCodex
{
    /// <summary>Integer corner coordinates. Tile (x,y) occupies [x,x+1] x [y,y+1]. +Y is Up.</summary>
    public static class AnimalRangeUtility
    {
        public static List<Vector2Int> GetCells(AnimalGrade grade, Vector2Int corner, AnimalFacing facing,
            Predicate<Vector2Int> canManage = null)
        {
            if (grade == null) throw new ArgumentNullException("grade");
            if (grade.width < 1 || grade.depth < 1) throw new ArgumentOutOfRangeException("grade");
            if (!Enum.IsDefined(typeof(AnimalFacing), facing)) throw new ArgumentOutOfRangeException("facing");
            var result = new List<Vector2Int>(grade.CellCount);
            int startX = -(grade.width / 2);
            for (int y = 0; y < grade.depth; y++)
            for (int x = startX; x < startX + grade.width; x++)
            {
                Vector2Int local;
                switch (facing)
                {
                    case AnimalFacing.Right: local = new Vector2Int(y, x); break;
                    case AnimalFacing.Down: local = new Vector2Int(x, -y - 1); break;
                    case AnimalFacing.Left: local = new Vector2Int(-y - 1, -x - 1); break;
                    default: local = new Vector2Int(-x - 1, y); break;
                }
                var cell = corner + local;
                if (canManage == null || canManage(cell)) result.Add(cell);
            }
            return result;
        }

        /// <summary>Deduplicate large plants occupying several covered tiles by the game's stable plant ID.</summary>
        public static HashSet<string> GetUniquePlantIds(IEnumerable<Vector2Int> cells, Func<Vector2Int, string> plantAt)
        {
            if (plantAt == null) throw new ArgumentNullException("plantAt");
            var result = new HashSet<string>();
            foreach (var cell in cells)
            {
                var id = plantAt(cell);
                if (!string.IsNullOrEmpty(id)) result.Add(id);
            }
            return result;
        }
    }
}
