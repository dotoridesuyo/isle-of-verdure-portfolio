using System;
using System.Collections.Generic;
using UnityEngine;

namespace IsleOfVerdure.AnimalCodex
{
    /// <summary>Connect to the existing farm grid; this component does not occupy a plant tile or execute care actions.</summary>
    public sealed class AnimalCarePlacement : MonoBehaviour
    {
        [SerializeField] private AnimalCatalog catalog;
        [SerializeField] private string animalId = "A001";
        [SerializeField] private Vector2Int corner;
        [SerializeField] private AnimalFacing facing = AnimalFacing.Down;
        private List<Vector2Int> cells = new List<Vector2Int>();
        private Predicate<Vector2Int> canManage;
        public event Action<IReadOnlyList<Vector2Int>, IReadOnlyList<Vector2Int>> RangeChanged;
        public IReadOnlyList<Vector2Int> Cells { get { return cells.AsReadOnly(); } }
        public string AnimalId { get { return animalId; } }

        public void Configure(AnimalCatalog source, string speciesId, Predicate<Vector2Int> validCell)
        {
            if (source == null || source.Find(speciesId) == null) throw new ArgumentException("Unknown animal species.");
            catalog = source; animalId = speciesId; canManage = validCell;
            Recalculate();
        }

        public void SetPlacement(Vector2Int newCorner, AnimalFacing newFacing)
        {
            corner = newCorner; facing = newFacing; Recalculate();
        }

        public void RefreshGrid() { Recalculate(); }
        private void Recalculate()
        {
            if (catalog == null) return;
            var animal = catalog.Find(animalId);
            if (animal == null) return;
            var previous = cells;
            cells = isActiveAndEnabled ? AnimalRangeUtility.GetCells(catalog.Grade(animal.rarity), corner, facing, canManage) : new List<Vector2Int>();
            if (RangeChanged != null) RangeChanged(previous.AsReadOnly(), cells.AsReadOnly());
        }
        private void OnEnable() { Recalculate(); }
        private void OnDisable()
        {
            var previous = cells; cells = new List<Vector2Int>();
            if (RangeChanged != null) RangeChanged(previous.AsReadOnly(), cells.AsReadOnly());
        }
    }
}
