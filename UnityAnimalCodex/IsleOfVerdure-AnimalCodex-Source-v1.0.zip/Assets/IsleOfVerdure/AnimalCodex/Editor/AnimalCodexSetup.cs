using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace IsleOfVerdure.AnimalCodex.Editor
{
    public static class AnimalCodexSetup
    {
        public const string Root = "Assets/IsleOfVerdure/AnimalCodex";
        private const string Generated = Root + "/Generated";

        [MenuItem("Tools/Isle of Verdure/동물 도감/샘플 생성")]
        public static void CreateSample()
        {
            Directory.CreateDirectory(Generated);
            AssetDatabase.Refresh();
            string databasePath = Generated + "/AnimalCatalog.asset";
            var catalog = AssetDatabase.LoadAssetAtPath<AnimalCatalog>(databasePath);
            if (catalog == null)
            {
                catalog = AnimalCatalog.LoadDefault();
                AssetDatabase.CreateAsset(catalog,databasePath);
            }
            catalog.Validate();
            var previous = SceneManager.GetActiveScene();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
            try
            {
                var screen = new GameObject("AnimalCodex",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster),typeof(AnimalCodexProgress),typeof(AnimalCodexView));
                SceneManager.MoveGameObjectToScene(screen,scene);
                screen.GetComponent<Canvas>().renderMode=RenderMode.ScreenSpaceOverlay;
                var scaler=screen.GetComponent<CanvasScaler>();
                scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution=new Vector2(1280,800);scaler.matchWidthOrHeight=.5f;
                screen.GetComponent<AnimalCodexView>().Configure(catalog);
                var cameraObject = new GameObject("Main Camera",typeof(Camera));
                SceneManager.MoveGameObjectToScene(cameraObject,scene);
                var camera=cameraObject.GetComponent<Camera>();camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color32(233,237,222,255);camera.orthographic=true;
                cameraObject.tag="MainCamera";cameraObject.transform.position=new Vector3(0,0,-10);
                var prefabPath=AssetDatabase.GenerateUniqueAssetPath(Generated+"/AnimalCodex.prefab");
                PrefabUtility.SaveAsPrefabAsset(screen,prefabPath);
                var scenePath=AssetDatabase.GenerateUniqueAssetPath(Generated+"/AnimalCodexSample.unity");
                EditorSceneManager.SaveScene(scene,scenePath);
                Debug.Log("Animal codex sample created: "+scenePath+" | "+prefabPath);
                Selection.activeObject=AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath);
            }
            finally
            {
                EditorSceneManager.CloseScene(scene,true);
                if(previous.IsValid()&&previous.isLoaded)SceneManager.SetActiveScene(previous);
            }
            AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        }

        [MenuItem("Tools/Isle of Verdure/동물 도감/JSON으로 데이터 갱신")]
        public static void ReimportJson()
        {
            Directory.CreateDirectory(Generated);AssetDatabase.Refresh();
            var path=Generated+"/AnimalCatalog.asset";
            var catalog=AssetDatabase.LoadAssetAtPath<AnimalCatalog>(path);
            if(catalog==null){catalog=ScriptableObject.CreateInstance<AnimalCatalog>();AssetDatabase.CreateAsset(catalog,path);}
            var text=Resources.Load<TextAsset>(AnimalCatalog.ResourcePath);
            if(text==null)throw new InvalidOperationException("Animal catalog JSON is missing.");
            catalog.LoadJson(text.text);EditorUtility.SetDirty(catalog);AssetDatabase.SaveAssets();
            Selection.activeObject=catalog;
        }

        [MenuItem("Tools/Isle of Verdure/동물 도감/데이터·범위 검증")]
        public static void ValidateAll()
        {
            var catalog=AnimalCatalog.LoadDefault();
            try
            {
                Require(catalog.Animals.Length==10,"Exactly ten animal definitions.");
                int[] expected={2,4,6,9};
                foreach(AnimalRarity rarity in Enum.GetValues(typeof(AnimalRarity)))
                {
                    var grade=catalog.Grade(rarity);Require(grade.CellCount==expected[(int)rarity],"Grade size.");
                    foreach(AnimalFacing facing in Enum.GetValues(typeof(AnimalFacing)))
                    {
                        var origin=new Vector2Int(17,-4);
                        var cells=AnimalRangeUtility.GetCells(grade,origin,facing);
                        Require(cells.Count==grade.CellCount,"Directional cell count.");
                        Require(new HashSet<Vector2Int>(cells).Count==cells.Count,"No repeated tiles.");
                        foreach(var cell in cells)
                        {
                            var offset=cell-origin;
                            Require(facing==AnimalFacing.Up?offset.y>=0:facing==AnimalFacing.Down?offset.y<0:facing==AnimalFacing.Left?offset.x<0:offset.x>=0,"Only forward tiles.");
                        }
                        Require(AnimalRangeUtility.GetCells(grade,origin,facing,c=>false).Count==0,"Blocked cells are not replaced.");
                        var clipped=AnimalRangeUtility.GetCells(grade,origin,facing,c=>c.x==17);
                        Require(clipped.TrueForAll(c=>c.x==17),"Boundary predicate honored.");
                    }
                }
                var shared=AnimalRangeUtility.GetUniquePlantIds(new[]{Vector2Int.zero,Vector2Int.one,new Vector2Int(2,2)},c=>c.x<2?"plant-1":null);
                Require(shared.Count==1,"A multi-tile plant is handled once.");
                var go=new GameObject("AnimalCodex Save Validation");
                try
                {
                    var progress=go.AddComponent<AnimalCodexProgress>();
                    progress.ImportJson("{\"version\":1,\"records\":[{\"id\":\"A001\",\"state\":2},{\"id\":\"A001\",\"state\":1},{\"id\":\"A002\",\"state\":99}]}");
                    Require(progress.GetState("A001")==AnimalDiscovery.Collected,"Repeated records preserve highest state.");
                    Require(progress.GetState("A002")==AnimalDiscovery.Undiscovered,"Invalid discovery states ignored.");
                    var saved=progress.ExportJson();progress.ImportJson(saved);
                    Require(progress.GetState("A001")==AnimalDiscovery.Collected,"Save round-trip.");
                }
                finally{UnityEngine.Object.DestroyImmediate(go);}
                Debug.Log("ANIMAL_CODEX_VALIDATION_PASS: 10 animals, 16 directional footprints, boundary clipping, target deduplication and save validation.");
            }
            finally{UnityEngine.Object.DestroyImmediate(catalog);}
        }

        // Optional batch validation/export entry point. Writes only inside the calling project and its parent output directory.
        public static void ValidateAndExport()
        {
            ValidateAll();CreateSample();
            File.WriteAllText(Root+"/Docs/VALIDATION.txt",
                "신록의 섬 동물 도감 — 실제 검증 기록\n"+
                "검증 엔진: Unity "+Application.unityVersion+"\n"+
                "통과: C# 컴파일, JSON 읽기, 10종 데이터, 네 등급, 16개 방향 패턴, 전방 제한, 경계/장애물 제외, 대형 식물 중복 방지, 저장 데이터 검증.\n"+
                "생성: ScriptableObject 데이터, 샘플 프리팹, 샘플 씬, Unity AssetPackage.\n"+
                "한계: Unity 6 에디터가 이 환경에 없어 Unity 6 플레이 모드/실제 게임 연동/기기별 입력/폰트 시각 검증은 수행하지 못함.\n"+
                "화면은 Unity 기본 uGUI API를 사용. Unity 6 프로젝트에서 최종 Play 확인 필요.\n"+
                "신규 Input System 분기는 해당 패키지가 있는 대상 프로젝트에서 확인 필요.\n");
            AssetDatabase.ImportAsset(Root+"/Docs/VALIDATION.txt");
            var output=Environment.GetEnvironmentVariable("VERDURE_ANIMAL_PACKAGE_OUTPUT");
            if(string.IsNullOrEmpty(output))output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../신록의-섬-동물도감-Unity-v1.0.unitypackage"));
            AssetDatabase.ExportPackage(Root,output,ExportPackageOptions.Recurse);
            Debug.Log("ANIMAL_CODEX_PACKAGE_EXPORTED: "+output);
        }
        private static void Require(bool condition,string message)
        {if(!condition)throw new InvalidOperationException("Animal codex validation failed: "+message);}
    }

    public sealed class AnimalPortraitImport : AssetPostprocessor
    {
        private void OnPreprocessTexture()
        {
            if(!assetPath.EndsWith("/Resources/VerdureAnimalCodex/animal-portraits.png",StringComparison.Ordinal))return;
            var importer=(TextureImporter)assetImporter;
            importer.textureType=TextureImporterType.Default;importer.alphaIsTransparency=true;
            importer.mipmapEnabled=false;importer.isReadable=false;importer.maxTextureSize=2048;
            importer.textureCompression=TextureImporterCompression.Uncompressed;importer.filterMode=FilterMode.Bilinear;
        }
    }
}
